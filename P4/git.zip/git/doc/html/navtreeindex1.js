var NAVTREEINDEX1 =
{
"repSopaLetras.html#faSopaLetras":[4,1],
"repSopaLetras.html#invSopaLetras":[4,0],
"sopaletras_8h_source.html":[6,0,0,7],
"structArbolGeneral_1_1nodo.html":[5,0,0,2],
"structArbolGeneral_1_1nodo.html#a3b8075b9fd0dc27c2272ba48bd9a9221":[5,0,0,2,2],
"structArbolGeneral_1_1nodo.html#a8d0a58447171461212942f9308ef4f36":[5,0,0,2,0],
"structArbolGeneral_1_1nodo.html#ab4d70a0179e8450b2842bbf1a6481402":[5,0,0,2,3],
"structArbolGeneral_1_1nodo.html#ab7223965c5a62aa93895f3decd7a109a":[5,0,0,2,1],
"structtripleta.html":[5,0,5],
"structtripleta.html#a10999ca5e144ce1953302451decfd505":[5,0,5,2],
"structtripleta.html#a1d28eda84ffb6aa304e5cf136c65780d":[5,0,5,1],
"structtripleta.html#a742a9fba5472f87c89b069b5553028ad":[5,0,5,4],
"structtripleta.html#adaf8b982b685a6b0eb6e8388cc8c753b":[5,0,5,3],
"structtripleta.html#ae4eb100c0f4e1af08131be06a1595fc4":[5,0,5,0]
};
