var classOntologias_1_1const__iterator =
[
    [ "const_iterator", "classOntologias_1_1const__iterator.html#a054ff3d00e38e7214b5d70b5dd330097", null ],
    [ "const_iterator", "classOntologias_1_1const__iterator.html#a7fd5e28940dde9545eb5f25882a7b50a", null ],
    [ "GetJerarquia", "classOntologias_1_1const__iterator.html#aed07d92911526549e6b27e6409a9bb66", null ],
    [ "GetSuperPalabra", "classOntologias_1_1const__iterator.html#ac7309f1ecfbc68380d5a3104d25af648", null ],
    [ "operator!=", "classOntologias_1_1const__iterator.html#a92a9434028af7fa2423c05287c162f89", null ],
    [ "operator*", "classOntologias_1_1const__iterator.html#a20b5f6bd65283835edd45d88997970c5", null ],
    [ "operator++", "classOntologias_1_1const__iterator.html#a868a7473719f1f00c7fbecfaed4fbf7b", null ],
    [ "operator==", "classOntologias_1_1const__iterator.html#aa7bfebf8bd898b739429078211168e11", null ],
    [ "Ontologias", "classOntologias_1_1const__iterator.html#abb15a84ae9ff91f9e3b0bcc1ce75f954", null ],
    [ "it", "classOntologias_1_1const__iterator.html#a7441b46b8689de37959b3f57832d154f", null ],
    [ "level", "classOntologias_1_1const__iterator.html#a52c82df2b7cb4f10cda0832174db325d", null ]
];