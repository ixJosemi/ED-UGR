var structtripleta =
[
    [ "operator<", "structtripleta.html#ae4eb100c0f4e1af08131be06a1595fc4", null ],
    [ "operator=", "structtripleta.html#a1d28eda84ffb6aa304e5cf136c65780d", null ],
    [ "col", "structtripleta.html#a10999ca5e144ce1953302451decfd505", null ],
    [ "d", "structtripleta.html#adaf8b982b685a6b0eb6e8388cc8c753b", null ],
    [ "fila", "structtripleta.html#a742a9fba5472f87c89b069b5553028ad", null ]
];