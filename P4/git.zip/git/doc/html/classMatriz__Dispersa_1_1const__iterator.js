var classMatriz__Dispersa_1_1const__iterator =
[
    [ "const_iterator", "classMatriz__Dispersa_1_1const__iterator.html#a6be9241ead12f8779fd81bc036d58db1", null ],
    [ "operator!=", "classMatriz__Dispersa_1_1const__iterator.html#aa1d65723966a59a04e1d79c8e311541d", null ],
    [ "operator*", "classMatriz__Dispersa_1_1const__iterator.html#a6e280c35d9fd250d94201ed45144db78", null ],
    [ "operator++", "classMatriz__Dispersa_1_1const__iterator.html#ac2735ae9dce339daf03b2d56100dde3d", null ],
    [ "operator--", "classMatriz__Dispersa_1_1const__iterator.html#a834bf7f34bdfe9f3b65b9eedb0bb46c1", null ],
    [ "operator==", "classMatriz__Dispersa_1_1const__iterator.html#a4de3c3c4faa25620794e7736b0267ed5", null ],
    [ "Matriz_Dispersa", "classMatriz__Dispersa_1_1const__iterator.html#abba69238a7caad6720a36fea6545828c", null ],
    [ "p", "classMatriz__Dispersa_1_1const__iterator.html#a8a7dd8ce1fc7dcedf79a48e6258f1d86", null ]
];