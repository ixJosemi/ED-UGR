var classPreguntasED =
[
    [ "PreguntasED", "classPreguntasED.html#ae700090cab12c4f4141198f01f2083ad", null ],
    [ "BarajarPreguntas", "classPreguntasED.html#a318566f945106d4a686179f5c372fb9e", null ],
    [ "CreaTematica", "classPreguntasED.html#ae66cdf311a03d6c4081a1aae7686241f", null ],
    [ "GetPregunta", "classPreguntasED.html#a6f5714e6c6585b985080587a666419c6", null ],
    [ "GetTitleTematica", "classPreguntasED.html#a55d9974f8160d7b6aac5349dbdf2bae4", null ],
    [ "IniciaConceptosTemaEscogido", "classPreguntasED.html#adc5fc0098c812ebf3cf16efd1559e2a5", null ],
    [ "MuestraTematicas", "classPreguntasED.html#a3a85dc53b8aa1c5d1c4662c5800ac26a", null ],
    [ "num_preguntas", "classPreguntasED.html#afa064b9f4b71ab4d0733366c46b9c45a", null ],
    [ "SacaPregunta", "classPreguntasED.html#aa41f184e1aeef4704d7db2c9226f2038", null ],
    [ "SetTematica", "classPreguntasED.html#a8c2497ce7e02c37bcc07af6299c2efd4", null ],
    [ "next_pregunta", "classPreguntasED.html#a47755d112bde5064cdba432f083eb71c", null ],
    [ "Ot", "classPreguntasED.html#a8fd9d7e045db4b8866938a8255631505", null ],
    [ "preguntas_hechas", "classPreguntasED.html#aebde32c440bac4776c9c9f3f7b005b88", null ],
    [ "preguntas_tema", "classPreguntasED.html#a990e687fdd2d3586c3d2f039178624d6", null ],
    [ "tema_level", "classPreguntasED.html#adbbfbe807ce4cbf02b9267f6035ca1e7", null ],
    [ "temas", "classPreguntasED.html#a879738068695748760e49222b7e2f80f", null ],
    [ "tematica_escogida", "classPreguntasED.html#ad88b8732fae866035cd2b23a5c881f56", null ]
];