var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "ArbolGeneral.cpp", "ArbolGeneral_8cpp_source.html", null ],
    [ "ArbolGeneral.h", "ArbolGeneral_8h_source.html", null ],
    [ "colormod.h", "colormod_8h_source.html", null ],
    [ "matrizdispersa.cpp", "matrizdispersa_8cpp_source.html", null ],
    [ "matrizdispersa.h", "matrizdispersa_8h_source.html", null ],
    [ "Ontologias.h", "Ontologias_8h.html", [
      [ "Ontologias", "classOntologias.html", "classOntologias" ],
      [ "iterator_level", "classOntologias_1_1iterator__level.html", "classOntologias_1_1iterator__level" ],
      [ "const_iterator_level", "classOntologias_1_1const__iterator__level.html", "classOntologias_1_1const__iterator__level" ],
      [ "iterator", "classOntologias_1_1iterator.html", "classOntologias_1_1iterator" ],
      [ "const_iterator", "classOntologias_1_1const__iterator.html", "classOntologias_1_1const__iterator" ]
    ] ],
    [ "PreguntasED.h", "PreguntasED_8h_source.html", null ],
    [ "sopaletras.h", "sopaletras_8h_source.html", null ]
];