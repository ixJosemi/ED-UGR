var classOntologias_1_1iterator =
[
    [ "iterator", "classOntologias_1_1iterator.html#ad2d36c6b1ed6cb3bdf59a13eb47252e9", null ],
    [ "iterator", "classOntologias_1_1iterator.html#a995ec31779fb799d247b5cdb0bf39201", null ],
    [ "GetJerarquia", "classOntologias_1_1iterator.html#a54c886b108d4b72b7db050611c3d7534", null ],
    [ "GetSuperPalabra", "classOntologias_1_1iterator.html#a315f89c4f7a35d331474d1699cd7a955", null ],
    [ "operator!=", "classOntologias_1_1iterator.html#acb1d213de1254cfba6418752c4e00e3a", null ],
    [ "operator*", "classOntologias_1_1iterator.html#aae7ea4c942db5be17e923bdac15d67ab", null ],
    [ "operator++", "classOntologias_1_1iterator.html#a5952697482614146ed41d9a55a468a2f", null ],
    [ "operator==", "classOntologias_1_1iterator.html#abcb9d0d51d1a494fae555e3072a4cfe4", null ],
    [ "const_iterator", "classOntologias_1_1iterator.html#ac220ce1c155db1ac44146c12d178056f", null ],
    [ "Ontologias", "classOntologias_1_1iterator.html#abb15a84ae9ff91f9e3b0bcc1ce75f954", null ],
    [ "it", "classOntologias_1_1iterator.html#aedb0d6b2af067f3be1dc8d523890205a", null ]
];