var annotated_dup =
[
    [ "ArbolGeneral", "classArbolGeneral.html", "classArbolGeneral" ],
    [ "Matriz_Dispersa", "classMatriz__Dispersa.html", "classMatriz__Dispersa" ],
    [ "Ontologias", "classOntologias.html", "classOntologias" ],
    [ "PreguntasED", "classPreguntasED.html", "classPreguntasED" ],
    [ "Sopa_Letras", "classSopa__Letras.html", "classSopa__Letras" ],
    [ "tripleta", "structtripleta.html", "structtripleta" ]
];