var structArbolGeneral_1_1nodo =
[
    [ "drcha", "structArbolGeneral_1_1nodo.html#a8d0a58447171461212942f9308ef4f36", null ],
    [ "etiqueta", "structArbolGeneral_1_1nodo.html#ab7223965c5a62aa93895f3decd7a109a", null ],
    [ "izqda", "structArbolGeneral_1_1nodo.html#a3b8075b9fd0dc27c2272ba48bd9a9221", null ],
    [ "padre", "structArbolGeneral_1_1nodo.html#ab4d70a0179e8450b2842bbf1a6481402", null ]
];