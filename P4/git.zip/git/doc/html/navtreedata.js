var NAVTREE =
[
  [ "SopaLetras", "index.html", [
    [ "Rep del TDA Arbol General", "repArbolGeneral.html", [
      [ "Invariante de la representación", "repArbolGeneral.html#invArbolGeneral", null ],
      [ "Función de abstracción", "repArbolGeneral.html#faArbolGeneral", null ]
    ] ],
    [ "Rep del TDA Matriz dispersa", "repMatriz.html", [
      [ "Invariable de la representacion", "repMatriz.html#invConjunto", null ],
      [ "Funcion de abstraccion", "repMatriz.html#faConjunto", null ]
    ] ],
    [ "Rep del TDA Ontologias", "repOntologias.html", [
      [ "Invariante de la representación", "repOntologias.html#invOntologias", null ],
      [ "Función de abstracción", "repOntologias.html#faOntologias", null ]
    ] ],
    [ "Rep del TDA PreguntasED", "repPreguntasED.html", [
      [ "Invariante de la representación", "repPreguntasED.html#invPreguntasED", null ],
      [ "Función de abstracción", "repPreguntasED.html#faPreguntasED", null ]
    ] ],
    [ "Rep del modulo Sopa de Letras", "repSopaLetras.html", [
      [ "Invariante de la representacion", "repSopaLetras.html#invSopaLetras", null ],
      [ "Funcion de abstraccion", "repSopaLetras.html#faSopaLetras", null ]
    ] ],
    [ "Clases", "annotated.html", [
      [ "Lista de clases", "annotated.html", "annotated_dup" ],
      [ "Índice de clases", "classes.html", null ],
      [ "Miembros de las clases", "functions.html", [
        [ "Todo", "functions.html", null ],
        [ "Funciones", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "typedefs", "functions_type.html", null ],
        [ "Funciones relacionadas", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ]
    ] ],
    [ "Ejemplos", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"ArbolGeneral_8cpp_source.html",
"repSopaLetras.html#faSopaLetras"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';