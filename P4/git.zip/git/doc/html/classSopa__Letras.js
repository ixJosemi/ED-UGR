var classSopa__Letras =
[
    [ "Sopa_Letras", "classSopa__Letras.html#a8c18743126e49daeb6f03a665b6fa044", null ],
    [ "colocarpalabra", "classSopa__Letras.html#a3f337aaac02b77ddf6c2e906d4b286d3", null ],
    [ "Comprobar_Palabra", "classSopa__Letras.html#a091e263072a929abdd6fed3a9249cad3", null ],
    [ "descubiertas", "classSopa__Letras.html#aab2c0355dae1d657096a70624d085565", null ],
    [ "esposiblecolocar", "classSopa__Letras.html#a167397de45b83b052e73154575887573", null ],
    [ "getpalabrasocultas", "classSopa__Letras.html#a665a6172e44c6c1ed916a5a2a80561f9", null ],
    [ "nodescubiertas", "classSopa__Letras.html#ac215241ac78e01729461ffdfe43ec8d1", null ],
    [ "palabranodescubierta", "classSopa__Letras.html#af8297562d3f986acd8a1239e98ac1019", null ],
    [ "Poner_Acertada", "classSopa__Letras.html#a62bc5f8ed8fc2bfde66631614c32ace9", null ],
    [ "settitulo", "classSopa__Letras.html#a4269efffb0182074f22c89cc12728c37", null ],
    [ "bold_off", "classSopa__Letras.html#aee84db901d63d475cc92544c4b35e6d7", null ],
    [ "bold_on", "classSopa__Letras.html#adb7c583c5d1c09365b0024df727f00c5", null ],
    [ "operator<<", "classSopa__Letras.html#a6b3b0f0040a0d7222c4840d4668f4e0d", null ],
    [ "operator>>", "classSopa__Letras.html#add7bb557359657228705f0c7162738e7", null ],
    [ "acertadas", "classSopa__Letras.html#a89456fe02955a315610bb71d09efd5b4", null ],
    [ "direccion", "classSopa__Letras.html#a0953e6321f049966337401438c304eeb", null ],
    [ "encontradas", "classSopa__Letras.html#a2c7c1b1205659ab3467031d50d8a145a", null ],
    [ "ocultas", "classSopa__Letras.html#a5323472c8948e7c757922bdf984d1953", null ],
    [ "sp", "classSopa__Letras.html#abfda3b3a4f4f50834570f13bcab041ea", null ],
    [ "titulo", "classSopa__Letras.html#aa0c3936858d8134909056352eb910f8b", null ]
];