/*************************************************/
/* Implementación del modulo de PreguntasED      */
/* Jose Miguel Hernandez Garcia                  */
/* David Redondo Correa                          */
/* 2C C3                                         */
/*************************************************/

#include "PreguntasED.h"
#include <vector>
#include <algorithm>    // std::random_shuffle

using namespace std;

/* Sobrecarga del operador de salida de un set de string */
static ostream & operator<<(ostream & s, set<string> & p) {
    set<string>::iterator it = p.begin();
    
    for(; it!=p.end(); ++it) // Pintamos un set
    	cout << (*it) << ", ";
    
    return s;
}

/* Obtiene todas las tematicas de un nivel fijado */
void PreguntasED::CreaTematica(){
	Ontologias::iterator_level oit = Ot.beginl(tema_level); // Iterador de ontologias por niveles 

	for(; oit != Ot.endl(); ++oit)
		temas.push_back(oit); // Añadimos al vector tema, el tema al que apunta el
													// iterador en cada vuelta
}

/* Muestra las tematicas en el nivel */
void PreguntasED::MuestraTematicas(){
	vector<Ontologias::iterator_level>::const_iterator vit = temas.begin();
	int contador = 0;

	for(; vit != temas.end(); ++vit){ 
		cout << "Tema " << contador << ": ";
		contador++;
		Ontologias::iterator_level it = (*vit);
		set <string> s = (*it).first;
		cout << s << endl;
	}
}

/* Modifica la tematica escogida a un valor */
void PreguntasED::SetTematica(int i){
	tematica_escogida = i-1; // Para evitar que coja el incorrecto
}

/* Obtiene el titulo de una tematica */
string PreguntasED::GetTitleTematica(){ 
	Ontologias::iterator_level oit; // Declaramos iterador de ontologias
	oit = temas[tematica_escogida]; // Apunta a la tematica escogida

	// Ahora hay que obtener el titulo de esa temática, que será el set de 
	// string que hay de primer elemento
	set <string>::iterator sit = (*oit).first.begin();

	// Una vez tenemos el set, lo transformamos a un string
	string titulo;

	for(; sit != (*oit).first.end(); ++sit){
		titulo += (*sit);
		titulo += ", ";
	}

	// Como por ultimo va a insertar una coma, la borramos
	titulo.pop_back();

	return titulo;
}

/* Almacena todas las definiciones de la tematica escogida */ 
void PreguntasED::IniciaConceptosTemaEscogido() {
	Ontologias::iterator_level itinicio = temas[tematica_escogida];
	Ontologias::iterator_level itfin = temas[tematica_escogida+1];
	Ontologias::iterator inicio(itinicio);
	Ontologias::iterator fin(itfin);

	if(tematica_escogida == temas.size()-1) // Si estamos en el ultimo tema
		fin = Ot.end();											// el final será el ultimo nodo de Ot

	while(inicio != fin) {
		preguntas_tema.push_back(inicio);
		++inicio;
	}

	next_pregunta = 0;
}


/* Baraja todas las preguntas de forma aleatoria */
void PreguntasED::BarajarPreguntas(){
	random_shuffle(preguntas_tema.begin(), preguntas_tema.end());
}

/* Devuelve la siguiente pregunta a realizar */
pair <set<string>, string> PreguntasED::SacaPregunta(){
	vector<Ontologias::iterator>::iterator vit = preguntas_tema.begin();

	advance(vit, next_pregunta); // Avanzamos hasta la pregunta
	int val = (*(*vit)).second;  // Cogemos el numero del significado
	string signi = Ot.GetDefinicion(val); // Cogemos el significado

	// Rellenamos el set de sinonimos
	set <string> palabras;
	set <string>::iterator sit = (*(*vit)).first.begin();

	for(; sit != (*(*vit)).first.end(); ++sit)
		palabras.insert(*sit);

	next_pregunta++; // Avanzamos next_pregunta a la siguiente
	preguntas_hechas.insert(val); // Incluimos la pregunta ya hecha

	return make_pair(palabras, signi);
}

/* Obtiene una pregunta con un indice determinado*/
pair <set<string>, string> PreguntasED::GetPregunta(int i){
	vector<Ontologias::iterator>::iterator vit = preguntas_tema.begin();

	advance(vit, i); // Avanzamos el iterador del vector
	int val = (*(*vit)).second; // Cogemos el numero del significado
	string signi = Ot.GetDefinicion(val); // Cogemos el significado
	
	// Rellenamos el set de sinonimos
	set <string> palabras; 
	set <string>::iterator sit = (*(*vit)).first.begin();

	for(; sit != (*(*vit)).first.end(); ++sit)
		palabras.insert(*sit);

	preguntas_hechas.insert(val); // Incluimos la pregunta ya hecha

	return make_pair(palabras, signi);
}