/*************************************************/
/* Implementación del modulo de Ontologias       */
/* Jose Miguel Hernandez Garcia                  */
/* David Redondo Correa                          */
/* 2C C3                                         */
/*************************************************/

#include <Ontologias.h>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <list>

using namespace std;

/* Comprueba si una palabra está en el conjunto o no */
pair <bool, Ontologias::const_iterator> Ontologias::Esta(const string & o) const{
  set<string>::const_iterator sit; // Iterador del conjunto
  ArbolGeneral<pair<set<string>, int>>::const_iter_preorden ait = ab.begin(); // Iterador del arbol
  Ontologias::const_iterator oit = begin();
  bool esta = false;

  while(ait != ab.end() && !esta) {
  	sit = (*ait).first.find(o); // El iterador del set apunta a la palabra a buscar

  	if(sit != (*ait).first.cend()) // Si está
  		esta = true; 						  	 // Ponemos esta a true para salir del while	
  	else{													 // Si NO está
  		++ait;											 // bajamos un nivel en el arbol
  		++oit;											 // Aumentamos en 1 el iterador de ontologias
  	}
  }

  if(!esta) // Si la palabra no esta, el iterador apunta al final
  	oit = end();
  
  return make_pair(esta, oit);
}

/* Elimina todas las ontologias */
void Ontologias::clear() {
	ab.clear(); 					// Borramos las ontologias del conjunto
	significados.clear();	// Borramos los significados de las ontologias
	n_palabras = 0;  			// El numero de palabras queda a 0
}

/* Devuelve el significado asociado a los sinonimos de una palabra y los 
	 sinonimos en si, junto a la palabra */
map <string, set <string>> Ontologias::GetSinonimos(const string & palabra) const {
	ArbolGeneral <pair<set<string>, int>>::const_iter_preorden ait = ab.begin();
	map <string, set<string>> m;
	set <string>::iterator sit;
	map<int, string>::const_iterator mit = significados.begin();
	bool esta = false;

	// Buscamos la palabra
	while(ait != ab.end() && !esta){
		sit = (*ait).first.find(palabra);

		if(sit != (*ait).first.end())
			esta = true;
		else
			++ait;
	}

	// Ahora cogemos el numero del significado
	int sig = (*ait).second;
	mit = significados.find(sig);			  // Buscamos la posición del significado
	string significado = (*mit).second; // Cogemos el significado

	// Rellenamos nuestro set
	set <string> aux;
	sit = (*ait).first.begin(); // Nuestro iterador del set apunta al principio 
														  // del set que contiene la palabra a buscar

	while(sit != (*ait).first.end()){ 
		aux.insert(*sit);
		++sit;
	}

	// Ahora hay que buscar las otras palabras con el mismo significado
	// Volvemos a recorrer el arbol de 0
	for(ait = ab.begin(); ait != ab.end(); ++ait){
		if((*ait).second == sig){
			sit = (*ait).first.begin();

			while(sit != (*ait).first.end()){
				aux.insert(*sit);
				++sit;
			}
		}
	}
	m.insert(make_pair(significado, aux)); // Creamos el mapa y lo devolvemos

	return m;
}

/* Devuelve todas las tematicas hasta la raiz de una palabra con significado
   concreto */
list <set<string>> Ontologias::GetSuperPalabra(const string & palabra, const string & signifi) const{
	list <set<string>> l;
	ArbolGeneral <pair<set<string>, int>>::const_iter_preorden ait = ab.begin();
	set <string>::iterator sit;
	map<int, string>::const_iterator mit = significados.begin();
	bool esta = false;

	// Buscamos la palabra
	while(ait != ab.end() && !esta){
		sit = (*ait).first.find(palabra);

		if(sit != (*ait).first.end()){
			int sig = (*ait).second;
			mit = significados.find(sig);

			if((*mit).second == signifi)
				esta = true;
			else
				++ait;
		}
		else
			++ait;
	}

	ait = ait.padre(); // Partimos del padre de nuestra palabra (El nodo) y no de la palabra en si

	while(ait.padre() != ab.begin()){
		set <string> aux;
		sit = (*ait).first.begin(); // El iterador del set apunta al inicio del subconjunto

		while(sit != (*ait).first.end())
			aux.insert(*sit);
		
		l.push_back(aux);  // Metemos el set en la lista
		ait = ait.padre(); // apuntamos al padre del iterador
	}

	return l;
}

/* Obtiene el significado de una posicion determinada */
string Ontologias::GetDefinicion(int pos){
	map<int, string>::iterator mit = significados.begin();
	mit = significados.find(pos);

	return (*mit).second;

}

/* Lectura de los significados de un fichero */
bool Ontologias::lee_significados(const char * fich_sig) {
	bool leido = true;
	string val;
	int pos, valor;
	string def, lectura;

	ifstream fi(fich_sig); // Abrimos el flujo de lectura del fichero

	if (!fi) // Si no podemos leer el fichero
		leido = false; 

	// Como el fichero está formado por VALOR DEFINICION, buscamos el primer espacio
	// para separar valor y definicion y crear nuestro mapa de significados
 	while(getline(fi, lectura)){
		pos = lectura.find(" ");      // Buscamos el primer espacio
		val = lectura.substr(0, pos); // Obtenemos el valor que corresponde
		valor = stoi(val);
		def = lectura.substr(pos+1, lectura.size()); // Obtenemos el significado
		significados.insert(make_pair(valor, def));  // Lo insertamos en el mapa de significados
  }

  fi.close();

  return leido;
}

/* Lee las ontologias y los significados de los ficheros dados */
bool Ontologias::Lee(const char * fich_jerarquia, const char * fic_significados) {
	bool leido = true;
	
	// Crea el flujo de entrada para el fichero Arbol_Ontologias.txt
	ifstream fi_jerarq(fich_jerarquia);

	// Leemos los significados y comprobamos si lo lee bien
	leido = lee_significados(fic_significados); 

	// Realizamos la comprobación,
	// Si no podemos crear alguno de los ficheros significará
	// que no se pueden leer y por tanto leido = false.
	if(!fi_jerarq)
		leido = false;

	if(leido)
		fi_jerarq >> ab;
						
	return leido;
}

/* Escribe las ontologias y los significados en los ficheros dados */
bool Ontologias::Escribe(const char * fich_jerarquia, const char * fic_significados) {
	bool escrito = true;

	// Definimos iterador para movernos por el mapa de significados
	typename map<int, string>::const_iterator mit;

	// Creamos los dos flujos de salida
	ofstream fo_jerarq(fich_jerarquia),
			 fo_signif(fic_significados);

	// Realizamos la comprobación,
	// Si no podemos crear alguno de los ficheros significará
	// que no se pueden escribir y por tanto escrito = false.
	if(!fo_jerarq || !fo_signif)
		escrito = false;
	
	if(escrito) {
		for(mit = significados.begin(); mit != significados.end(); ++mit)
			fo_signif << (*mit).first << " " << (*mit).second << "\n";
		
		// Ahora rellenamos el fichero de jerarquias
		fo_jerarq << ab;
	}

	return escrito;
}

